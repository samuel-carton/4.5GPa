Equipe 4.5GPa

Les sources de ce code restent la propri�t� de l'�quipe de d�veloppeurs.
(Equipe 4.5GPa,
	Samuel Carton
	Romain Desjuzeur
	Marion Jos�phine
	Mathieu Ponthoreau
	Nelson Tankeu Tchoufa)
Source code remains the property of the developers.
(Team 4.5GPa,
	Samuel Carton
	Romain Desjuzeur
	Marion Jos�phine
	Mathieu Ponthoreau
	Nelson Tankeu Tchoufa)